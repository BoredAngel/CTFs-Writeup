/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./pages/**/*.sh"],
  theme: {},
  plugins: [],
};
