from flask import *
import sqlite3, hashlib, requests, os, ipaddress, socket
from init_db import init_db
from datetime import timedelta
from urllib.parse import urlparse

UPLOAD_FOLDER = 'static/uploads'
app = Flask(__name__)
app.secret_key = os.urandom(16)
app.permanent_session_lifetime = timedelta(minutes=30)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def get_db_connection():
    conn = sqlite3.connect('asteroids.db', timeout=5)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def home():
    if 'username' in session:
        return redirect(url_for('catalog'))
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = hashlib.md5(request.form['password'].encode()).hexdigest()

    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE username=? AND password=?',
                        (username, password)).fetchone()
    conn.close()

    if user:
        session['username'] = user['username']
        session['role'] = user['role']
        return redirect(url_for('catalog'))
    else:
        return render_template('login.html', error='Invalid credentials.')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = hashlib.md5(request.form['password'].encode()).hexdigest()

        conn = get_db_connection()
        try:
            conn.execute('INSERT INTO users (username, password) VALUES (?, ?)',
                         (username, password))
            conn.commit()
            conn.close()
            return redirect(url_for('home'))
        except sqlite3.IntegrityError:
            conn.close()
            return render_template('register.html', error='Username already exists.')
    return render_template('register.html')

@app.route('/catalog')
def catalog():
    if 'username' not in session:
        return redirect(url_for('home'))

    search = request.args.get('search', '')

    conn = get_db_connection()
    if search:
        asteroids = conn.execute('SELECT * FROM asteroids WHERE name LIKE ?', (f'%{search}%',)).fetchall()
    else:
        asteroids = conn.execute('SELECT * FROM asteroids').fetchall()
    conn.close()

    return render_template('catalog.html', asteroids=asteroids, role=session['role'])

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if 'username' not in session or session['role'] != 'admin':
        return redirect(url_for('home'))

    conn = get_db_connection()

    if request.method == 'POST':
        if 'add' in request.form:
            name = request.form['name']
            description = request.form['description']
            conn.execute('INSERT INTO asteroids (name, description) VALUES (?, ?)', (name, description))
            conn.commit()
        elif 'delete' in request.form:
            asteroid_id = request.form['asteroid_id']
            conn.execute('DELETE FROM asteroids WHERE id=?', (asteroid_id,))
            conn.commit()

    asteroids = conn.execute('SELECT * FROM asteroids').fetchall()
    conn.close()
    return render_template('admin.html', asteroids=asteroids)

def filter_sqli(search_raw: str) -> str:
    
    blacklist = [
        'union', 'select', 'from', 'where', 'insert', 'delete', 'update', 'drop', 'or',' ',
        'table', 'database', 'schema', 'group', 'order', 'by', ';', '=', '<', '>','||','\t'
    ]
    
    search_lower = search_raw.lower()
    
    for word in blacklist:
        if word in search_lower:
            abort(403, description="SQL injection attempt detected: Blacklisted word found.")
    
    if 'access_level' not in search_lower:
        abort(403, description="SQL injection attempt detected: Invalid payload structure")
    
    return search_lower

@app.route('/internal/admin/search')
def internal_admin_search():
    if request.remote_addr != '127.0.0.1':
        return "Access denied", 403

    conn = get_db_connection()
    try:
        search_raw = request.args.get('q', '')
        if search_raw == '':
            query = "SELECT secret_name, secret_value FROM admin_secrets WHERE access_level <= 2"
        else:
            search = filter_sqli(search_raw)
            query = f"SELECT secret_name, secret_value FROM admin_secrets WHERE secret_name LIKE '{search}' AND access_level <= 2"

        rows = conn.execute(query).fetchall()
        
        result = ''
        for row in rows:
            result += f"{row['secret_name']}: {row['secret_value']}\n"
        if not result:
            result = "No secrets found"

        return result, 200, {'Content-Type': 'text/plain; charset=utf-8'}
    except Exception as e:
        return f"Error: {str(e)}"
    finally:
        conn.close()

def is_private_url(url: str):
    hostname = urlparse(url).hostname
    if not hostname:
        return True
    ip = socket.gethostbyname(hostname)
    return ipaddress.ip_address(ip).is_private

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'username' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    error_preview = None
    content_type = ''

    if request.method == 'POST':
        photo_url = request.form['photo_url']
        try:
            if is_private_url(photo_url):
                raise Exception("Direct access to internal host is forbidden.")

            os.makedirs(os.path.join('static', 'uploads'), exist_ok=True)

            resp = requests.get(photo_url, timeout=5)
            content_type = resp.headers.get('Content-Type', '')
            filename = f"{session['username']}_profile_fetched"
            filepath = os.path.join('static', 'uploads', filename)

            with open(filepath, 'wb') as f:
                f.write(resp.content)

            conn.execute(
                'UPDATE users SET profile_picture=?, profile_type=? WHERE username=?',
                (f'uploads/{filename}', content_type, session['username'])
            )
            conn.commit()

            if not content_type.startswith('image/'):
                try:
                    error_preview = resp.text[:500]
                except Exception as e:
                    error_preview = f"[!] Error reading content: {e}"

        except Exception as e:
            error_preview = f"[!] Error fetching image: {e}"

    user = conn.execute(
        'SELECT * FROM users WHERE username=?',
        (session['username'],)
    ).fetchone()
    conn.close()

    return render_template(
        'profile.html',
        user=user,
        content_type=content_type,
        error_preview=error_preview
    )

        
@app.route('/asteroid/<int:asteroid_id>')
def asteroid_detail(asteroid_id):
    if 'username' not in session:
        return redirect(url_for('home'))

    conn = get_db_connection()
    asteroid = conn.execute('SELECT * FROM asteroids WHERE id=?', (asteroid_id,)).fetchone()
    conn.close()

    if asteroid:
        return render_template('asteroid_detail.html', asteroid=asteroid, role=session['role'])
    else:
        return "Asteroid not found", 404
    
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

if __name__ == '__main__':
    init_db()
    app.run(debug=False,host='0.0.0.0',port=5000)